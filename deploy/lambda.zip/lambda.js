// "use strict";
// const awsServerlessExpress = require("aws-serverless-express");
// const app = require("./app");
// const server = awsServerlessExpress.createServer(app);
// exports.handler = (event, context) => {
//   awsServerlessExpress.proxy(server, event, context);
// };
"use strict";
// const cors = require("cors");
let books = [
  {
    bookName: "Rudest Book Ever",
    bookAuthor: "Shwetabh Gangwar",
    bookPages: 200,
    bookPrice: 240,
    bookState: "Available",
  },
  {
    bookName: "Do Epic Shit",
    bookAuthor: "Ankur Wariko",
    bookPages: 200,
    bookPrice: 240,
    bookState: "Available",
  },
];
let res;
module.exports.handler = (event, context, callback) => {
  if (event.path == "/books") {
    if (event.httpMethod == "GET") {
      res = books;
    } else if (event.httpMethod == "POST") {
      const inputBookName = event.body.bookName;
      const inputBookAuthor = event.body.bookAuthor;
      const inputBookPages = event.body.bookPages;
      const inputBookPrice = event.body.bookPrice;
      books.push({
        bookName: inputBookName,
        bookAuthor: inputBookAuthor,
        bookPages: inputBookPages,
        bookPrice: inputBookPrice,
        bookState: "Available",
      });
      res = "successfully added";
    } else if (event.httpMethod == "DELETE") {
      var requestedBookName = event.body.bookName;
      var j = 0;
      books.forEach((book) => {
        j = j + 1;
        if (book.bookName == requestedBookName) {
          books.splice(j - 1, 1);
        }
      });
      res = "deleted";
    }
  }
  if (event.path == "/books/issue") {
    if (event.httpMethod == "PUT") {
      var requestedBookName = req.body.bookName;
      console.log(req.body);
      books.forEach((book) => {
        if (book.bookName == requestedBookName) {
          book.bookState = "Issued";
        }
      });
      res = "successfully updated";
    }
  }
  if (event.path == "/books/return") {
    if (event.httpMethod == "PUT") {
      var requestedBookName = req.body.bookName;
      books.forEach((book) => {
        if (book.bookName == requestedBookName) {
          book.bookState = "Available";
        }
      });
      res = "successfully updated";
    }
  }
  const response = {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Headers": "*",
      "Access-Control-Allow-Methods": "*",
    },
    body: JSON.stringify(res),
  };
  callback(null, response);
};
